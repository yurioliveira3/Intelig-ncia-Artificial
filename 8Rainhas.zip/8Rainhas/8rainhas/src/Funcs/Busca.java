package Funcs;

import java.util.HashSet;
import java.util.Stack;
/**
 Busca cega - Intermediate, limitando 1 rainha por coluna.
 */
public class Busca {
    /**
     * @param n         Numero de rainhas no tabuleiro
     * @param debug     IF == true, ent�o printa o caminho percorrido at� encontrar um estado v�lido
     * @return 
     * @throws InterruptedException 
     **/
    public static boolean search (int n, boolean debug) throws InterruptedException {
    	
        // Inicializa��o das vari�veis e hash
        HashSet<String> historico = new HashSet<>(); // Controla quantas confs foram tentadas.
        int conf_tab = -1; // A primeira configura��o do tabuleiro com as n rainhas n�o vale.
        int call =1;
        // Cria uma nova pilha e come�a a popular o tabuleiro
        Stack<Tabuleiro> stack = new Stack<>();
        stack.push(new Tabuleiro(n));
      
        // Inicio da busca cega em profundidade
        while (!stack.isEmpty()) { // enquanto ainda der para popular a pilha do tipo tabuleiro continua
            Tabuleiro tabuleiro = stack.pop(); //retira a ultima conf do tabuleiro
            conf_tab++; //adiciona +1 conf pois vai modifica a antiga
            // Verifica se existem estados duplicados
            if (!historico.add(tabuleiro.toString())) continue;
            //Se debug estiver ativo, inicia o debug no tabuleiro
            if (debug) debug(tabuleiro);
            // Verifica se o processo de popula��o est� correto, e se nao existem rainhas se atacando
            if (tabuleiro.SetLocalRainhas.size() == n && tabuleiro.rainhasAtacando() == 0) {
            	finalResult(conf_tab, tabuleiro, call);
            	call++;
            	if(call>2) //printa no max 2 configua��es do tabuleiro
            		return true;
            }    
            // Caso o tabuleiro populado mas ainda estiverem rainhas se atacando continua para a prox instru��o
            else if (tabuleiro.SetLocalRainhas.size() == n && tabuleiro.rainhasAtacando() != 0)
                continue;
            // indexa a vari�vel, com a proxima coluna vazia
            int colun = primeiracolunasemrainha(tabuleiro);
            // Gerar o prox estado
            // Cada rainha tenta outra pos em sua coluna atual
            for (int y = 0; y < n; y++)
                if (!tabuleiro.posRainha(colun, y)) {
                    Tabuleiro temp = tabuleiro.clone();
                    temp.addQueen(colun, y);
                    stack.push(temp);
                }
        }
		return false;
    }
    /**
     * Print das possivei solu��es encontradas
     * @param board     	 o tabuleiro
     * @param configurations quantas tentativas
     */
    public static void finalResult (int configurations, Tabuleiro board, int call) {
    	System.out.println("-----RESULT-----");
        System.out.println("Tentativas at� um poss�vel n� objetivo ["+call+"]: " + configurations);
        System.out.println(board);
    }
    /**
     * Printa o tabuleiro a cada passo da busca.
     * @param board     o tabuleiro
     * @throws InterruptedException 
     */
    public static void debug (Tabuleiro board) throws InterruptedException {
        System.out.println(board);    
        double seconds = 0.5;
        Thread.sleep((int)(1000.0 * seconds));
    }
    /**
     * M�todo que encontra a primeira coluna vazia
     * @param Tabuleiro     tabuleiro no estado atual
     * @return          retorna o valor da coluna mais proxima vazia
     */
    private static int primeiracolunasemrainha (Tabuleiro tabuleiro) throws RuntimeException {
        for (int x = 0; x < tabuleiro.n; x++)
            if (!colunacomrainha(tabuleiro, x))
                return x;
      return 0;
    }
    /**
     * M�todo que complementa o anterior
     * @param Tabuleiro tabuleiro no estado atual
     * @param colun    coluna pesquisada
     * @return          retorna true se a coluna estiver vazia
     */
    private static boolean colunacomrainha (Tabuleiro tabuleiro, int colun) {
        for (int y = 0; y < tabuleiro.n; y++)
            if (tabuleiro.posRainha(colun, y))
                return true; // Achou rainha    
        return false;
    }
}
