package Funcs;

import java.util.*;
import java.util.Random;

/**
	Representa o tabuleiro/rainhas.
	N�o existe um array 2D e sim um hash
	Pois tem a propriedade da unidirecionalidade 
	onde n�o existe caminho de volta.
	Ideia de busca cega em profundidade
 */
public class Tabuleiro implements Comparable<Tabuleiro> {
    /**
     * As chaves do hash ser�o tratadas como o n� de queens
     * que podem atacar.
     * Se ouver 8 rainhas alinhadas em uma coluna, a localiza��o 
     * das rainhas a direita aumenta o n� da chave, a primeira sendo 1 
     * e a rainha no outro extremo, no caso a ultima 8 
     */
    public HashSet<Posicao> SetLocalRainhas;
    public HashMap<Posicao, Integer> hashLocaisdeAtaque;
    public int n; //Numero de N-Rainhas.
    /**
     * Constru��o do tabuleiro
     * @param n     Tamanho do tabuleiro
     */
    public Tabuleiro (int n) {
        this.n = n;
        clear(); //Limpa o mapa de entradas anteriores de hash
    }
    /**
     * Print do tabuleiro
     * @return string do tabuleiro no estado atual
     */
    @Override
    public String toString () {
        StringBuilder sb = new StringBuilder(); 
        for (int y = 0; y < n; y++) {
            for (int x = 0; x < n; x++) {
            	Posicao pos = new Posicao(x, y);
                if (SetLocalRainhas.contains(pos))
                    sb.append('R');
                else if (hashLocaisdeAtaque.containsKey(pos)) 
                    sb.append('*');
                else
                    sb.append('-');
                sb.append(" ");
            }
            sb.append("\n");
           }
        return new String(sb);
    }    
    public void clear () {
        hashLocaisdeAtaque = new HashMap<>();
        SetLocalRainhas = new HashSet<>();
    }
    /**
     * Adicionar rainhas ao tabuleiro
     * @param x     N� de linha do tabuleiro
     * @param y     N� de coluna do tabuleiro
     */
    public void addQueen (int x, int y) throws IndexOutOfBoundsException, IllegalStateException {

    	Posicao pos = new Posicao(x, y); //nova instancia de localiza��o

        if (!isInBounds(pos)) { //verifica se a posi�ao � valida [pos<n*n]
            System.out.println("Posi��o inv�lida!");
        }
        
        if (SetLocalRainhas.contains(pos)) { //verifica se a posicao possui rainhas
        	System.out.println("Posi��o possui rainhas!");
        }
        
        SetLocalRainhas.add(pos); //Adiciona aposi��o atual ao hash de posi��es
        loadAttack(pos); //Coloca os possivei locais de ataque da rainha, na posicao atual
    }
    /**
     * Remove uma rainha de uma localiza��o no tabuleiro
     * @param x     N� de linha do tabuleiro
     * @param y     N� de coluna do tabuleiro
     */
    public void removeQueen (int x, int y) {

        if (!posRainha(x, y))
            System.out.println("N�o existem rainhas aqui!");

        SetLocalRainhas.remove(new Posicao(x, y)); //Retira do tabuleiro a localiza��o
        hashLocaisdeAtaque.clear(); // remove a localiza��o da rainha atual no hash
        SetLocalRainhas.forEach((Posicao p) -> loadAttack(p));
    }
    /**
     * Verifica se existem rainhas na posi��o atual
     * @param x     N� de linha do tabuleiro
     * @param y     N� de coluna do tabuleiro
     * @return      true se existe uma rainha na localiza��o atual
     */
    public boolean posRainha(int x, int y) throws ArrayIndexOutOfBoundsException {
    	Posicao pos = new Posicao(x, y);

        if (!isInBounds(pos)) {
            System.out.println("Posi��o inv�lida!");
        }
        return SetLocalRainhas.contains(pos);
    }
    /**
     * Verifica se existe conflito de attack 
     * @return      true se o local � valido
     */
    public boolean localvalido() {
        int validSpots = n*n;
        validSpots -= hashLocaisdeAtaque.size();

        for (Posicao p : SetLocalRainhas) {
            if (!hashLocaisdeAtaque.containsKey(p)) {
                validSpots--;
            }
        }
        return validSpots != 0;
    }
    /**
     * Verifica se o local instanciado � v�lido
     * @param pos       local para verificar
     * @return          true se for v�lido
     */
    private boolean isInBounds (Posicao pos) {
        return
                pos.getX() < n && pos.getX() >= 0 && pos.getY() < n && pos.getY() >= 0;
    }
    /**
     * Coloca todos os possiveis ataques da queen no hashSet.
     * @param queen     localiza��o da queen 
     */
    private void loadAttack (Posicao queen) {

        //horizontal
        for (int x = 0; x < n; x++) {
        	Posicao pos = new Posicao(x, queen.getY());
            addAttack(pos);
        }
        removeAttack(queen); // Rainha atual n � v�lida, pois n�o pode se atacar

        //vertical
        for (int y = 0; y < n; y++) {
        	Posicao pos = new Posicao(queen.getX(), y);
            addAttack(pos);
        }
        removeAttack(queen); // Rainha atual n � v�lida, pois n�o pode se atacar

        //Diagonais
        //DIAGONAL PRIM�RIA
        for (int i = 1; i < n; i++) { 
        	Posicao pos = new Posicao(queen.getX()+i, queen.getY()-i);
            if (!isInBounds(pos)) break;
            addAttack(pos);
        }
        for (int i = 1; i < n; i++) { 
        	Posicao pos = new Posicao(queen.getX()-i, queen.getY()-i);
            if (!isInBounds(pos)) break;
            addAttack(pos);
        }
        //DIAGONAL SECUNDARIA
        for (int i = 1; i < n; i++) { 
        	Posicao pos = new Posicao(queen.getX()+i, queen.getY()+i);
            if (!isInBounds(pos)) break;
            addAttack(pos);
        }
        for (int i = 1; i < n; i++) { 
        	Posicao pos = new Posicao(queen.getX()-i, queen.getY()+i);
            if (!isInBounds(pos)) break;
            addAttack(pos);
        }    
}
    /**
     * Adiciona os locais que podem ser atacados pela rainha
     * @param pos   localiza��o para adicionar
     */
    private void addAttack (Posicao pos) {
        if (!hashLocaisdeAtaque.containsKey(pos)) {
            hashLocaisdeAtaque.put(pos, 1);
        } else {
            int amountOfAttacks = hashLocaisdeAtaque.get(pos);
            hashLocaisdeAtaque.put(pos, amountOfAttacks+1);
        }
    }
    /**
     * Remove os locais que podem ser atacados pela rainha
     * @param pos   localiza��o para remover
     */
    private void removeAttack (Posicao pos) {
        if (!hashLocaisdeAtaque.containsKey(pos)) {
            return;
        } else if (hashLocaisdeAtaque.get(pos) == 1) {
            hashLocaisdeAtaque.remove(pos);
        } else {
            int amountOfAttacks = hashLocaisdeAtaque.get(pos);
            hashLocaisdeAtaque.put(pos, amountOfAttacks-1);
        }
    }
    /**
     * Verifica uma localiza��o, se � safe para atacar
     * @param x     N� de linhas
     * @param y     N� de colunas
     * @return      true se nao existem rainhas atacando neste local
     */
    public boolean LocalValid (int x, int y) throws ArrayIndexOutOfBoundsException{
    	Posicao pos = new Posicao(x, y);

        if (!isInBounds(pos)) {
            System.out.println(pos.toString());
        }
        return !hashLocaisdeAtaque.containsKey(pos);
    }
    /**
     * Obt�m um conjunto de todas as rainhas atualmente no tabuleiro.
     * @return  rainhas atuais do tabuleiro
     */
    public HashSet<Posicao> getQueens () {
        return SetLocalRainhas;
    }
    /**
     * Verifica quantas rainhas estao se atacando
     * @return  numero de rainhas sob ataque
     */
    public int rainhasAtacando () {
        int count = 0;
        for (Posicao pos : SetLocalRainhas) {
            count += rainhasAtacandonestapos(pos.getX(), pos.getY());
        }
        return count;
    }
    /**
     * Verifica quantas rainhas estao atacando um determinado local
     * @param x     N� da linha
     * @param y     N� da coluna
     * @return  numero de rainhas atacando aquele local
     */
    public int rainhasAtacandonestapos (int x, int y) {
    	Posicao pos = new Posicao(x, y);
        if (!hashLocaisdeAtaque.containsKey(pos)) {
            return 0;
        } else {
            return hashLocaisdeAtaque.get(pos);
        }
    }
    /**
     * Retorna todas as posi��es do tabuleiro que nao tem rainhas
     * @return  hashSet contendo as posi�oes
     */
    public HashSet<Posicao> PosDisponiveis () {
        HashSet<Posicao> availablePositions = new HashSet<>();

        for (int y = 0; y < n; y++) {
            for (int x = 0; x < n; x++) {
            	Posicao pos = new Posicao(x, y);
                availablePositions.add(pos);
            }
        }
        SetLocalRainhas.forEach((Posicao l) -> availablePositions.remove(l));
        return availablePositions;
    }
    /**
     * Retorna todas as posi��es que naoestao sendo atacadas e nao sao rainhas
     * @return  hashSet contendo todas as possibilidades safe
     */
    public HashSet<Posicao> PosSafe () {
        HashSet<Posicao> availablePositions = new HashSet<>();

        for (int y = 0; y < n; y++) {
            for (int x = 0; x < n; x++) {
            	Posicao pos = new Posicao(x, y);
                if (!SetLocalRainhas.contains(pos)
                        && !hashLocaisdeAtaque.containsKey(pos)) {
                    availablePositions.add(pos);
                }
            }
        }
        return availablePositions;
    }
    /**
     * Retorna uma c�pia detalhada inst�ncia do tabuleiro. �til para fazer heran�a
     * @return  c�pia do tabuleiro
     */
    public Tabuleiro clone () {
        Tabuleiro newTabuleiro = new Tabuleiro(n);
        newTabuleiro.hashLocaisdeAtaque.putAll(hashLocaisdeAtaque);
        newTabuleiro.SetLocalRainhas.addAll(SetLocalRainhas);
        return newTabuleiro;
    }
    /**
     * Usa uma pontua��o heuristica para compara��o
     * @param Tabuleiro     tabuleiro para comparar
     * @return          num negativo ou positivo, para comparar se � melhor que a pontua��o atual
     */
    @Override
    public int compareTo(Tabuleiro Tabuleiro) {
        return Tabuleiro.rainhasAtacando() - rainhasAtacando();
    }
    /**
     * Verifica a igualdade com base nos locais da Rainha.
     * @param o     tabuleiro
     * @return      true se existem rainhas em locais iguais
     */
    @Override
    public boolean equals (Object o) {
        if (!(o instanceof Tabuleiro)) {
            return false;
        }

        Tabuleiro Tabuleiro = (Tabuleiro) o;

        return Tabuleiro.getQueens().equals(getQueens());

    }
    /**
     * Cria um tabuleiro com as n queens na diagonal
     * @param n     N� de rainhas
     * @return      tabuleiro
     */
    public static Tabuleiro makeTabuleiroWithQueensOnDiagonal (int n) {
        Tabuleiro Tabuleiro = new Tabuleiro(n);
        for (int i = 0; i < n; i++) {
            Tabuleiro.addQueen(i, i);
        }
        return Tabuleiro;
    }
    /**
     * Cria um novo tabuleiro com 1 rainha por coluna
     * Coluna escolhida de forma randomica.
     * @param n     tamanho do tabuleiro
     * @param r     random objeto para selecionar um coluna
     * @return      Novo tabuleiro com cada rainha em uma coluna
     */
    public static Tabuleiro RainhaPColun (int n, Random r) {

        int[] array = new int[n];

        for (int i = 0; i < n; i++) {
            array[i] = i;
        }

        shuffleArray(array, r);

        Tabuleiro Tabuleiro = new Tabuleiro(n);

        for (int i = 0; i < n; i++) {
            Tabuleiro.addQueen(i, array[i]);
        }
        return Tabuleiro;
    }
    /**
     * Auxiliar do metodo acima
     * Este shuffle ir� selecionar o valor que ir� indexiar a coluna Y
     * @param array     array shuffle
     * @param r         objeto random para selecionar o Y
     */
    private static void shuffleArray (int[] array, Random r) {
        for (int i = 0; i < array.length; i++) {
            swap(array, i, r.nextInt(array.length));
        }
    }
    /**
     * Auxiliar do shuffle
     * Alterna os elementos com base em seu �ndice na matriz.
     * @param array     array shuffle
     * @param i         index do primeiro elemento
     * @param j         index do segundo elemento
     */
    private static void swap (int[] array, int i, int j) {
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
}