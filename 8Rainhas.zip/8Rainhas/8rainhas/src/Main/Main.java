/*Refer�ncia para desenvolvimento do projeto
*https://www.caelum.com.br/apostila-java-estrutura-dados/tabelas-de-espalhamento/#9-20-exercicios-tabela-de-espalhamento-4
*N�o consegui fazer funcionar com �rvore, n�o sei se o problema era por usar o Hash, ou o tipo de busca cega intermediate.
*/
package Main;

import java.util.*;
import Funcs.*;

public class Main {
	
	private static Scanner scanner;
    /**
     * Main call
     * @param rainhas   retorno do numero de rainhas que o usr digitou
     * @param debug     retorno de debugar o cod ou nao
     */
	public static void main(String[] args) throws Exception {
		int rainhas = num_queens();
		boolean debug = debug_or_not();
		Busca.search(rainhas,debug);
	}
    /**
     * Numero de rainhas 
     * @param input1	numero de rainhas que o usr digitou
     */	
	public static int num_queens() {
		int input1 = 4; //Default
		
		System.out.println("Rainhas: ");
		scanner = new Scanner(System.in);
		input1 = scanner.nextInt();
		
		if(input1 < 4) {
			 System.out.println("Numero de rainhas deve ser no minimo 4.");
	         System.exit(-1);
		}	
		return input1;
	}
    /**
     * Debugar o codigo ou nao
     * @param input2	boolean que o usr digitou
     */
	public static boolean debug_or_not() {
		boolean input2 = false; //Default
		
		System.out.println("Debug?[true/false]"
				+ " Note: If debug true - print all attempt");
		scanner = new Scanner(System.in);
		input2 = scanner.nextBoolean();
		
		if(input2 != true && input2 != false) {
			 System.out.println("Entradas v�lidas s�o: 'true' ou 'false'");
	         System.exit(-1);
		}
		return input2;
	}
}
