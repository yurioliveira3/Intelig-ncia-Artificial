import java.util.*;
import java.util.Scanner;
//MAIN
public class Main {
    
	public static Scanner scanner;
		
	public static void main(String[] args){
		
		int tamanho = cubo_lenght();
		int obstaculos = obs(tamanho);
		celula_bloco pos_start =  posicao_ini(tamanho);
		celula_bloco pos_goal =   posicao_final(pos_start,tamanho);
		System.out.println("POS START: "+pos_start.toString()+"\nPOS GOAL: "+pos_goal.toString()+"\nTamanho Cubo: ["+tamanho+"x"+tamanho+"x"+tamanho+"]\nObstaculos[BL]: "+obstaculos);
		buscaA.ini(pos_start,pos_goal,tamanho,obstaculos); //CALL PARA INICIO DO PROCESSO
	}
	
	private static int cubo_lenght() { // CRIAR O CUBO
		
		System.out.println("Tamanho do cubo:[x^3]");
		scanner = new Scanner(System.in);
		int tamanho = scanner.nextInt();
		if(tamanho>0)
			return tamanho;
		else {
			System.out.print("Tamanho muito pequeno!, Reajustado para 3^3");
			return 3;
		}
	}

	public static celula_bloco posicao_ini(int tamanho){ // CRIAR A POSICAO DE START (RANDOM)
			
		Random geradori = new Random();
		Random geradorj = new Random();
		Random geradork = new Random();
		
		int ri = geradori.nextInt(tamanho); 
		int rj = geradorj.nextInt(tamanho);
		int rk = geradork.nextInt(tamanho);
		
		celula_bloco temp = new celula_bloco(ri,rj, rk);
	
		return temp;
	}
	
	private static celula_bloco posicao_final(celula_bloco pos_start, int tamanho) { // CRIAR A POSICAO DE GOAL (RANDOM)
		
	    java.util.Random x = new java.util.Random();
	    java.util.Random y = new java.util.Random();
	    java.util.Random z = new java.util.Random();
	    celula_bloco temp;
	    
	    boolean repeat=false;
	    	do{
	            repeat=false;
	            int num1 = x.nextInt(tamanho);
	            int num2 = y.nextInt(tamanho);
	            int num3 = z.nextInt(tamanho);
	            temp = new celula_bloco(num1,num2,num3);
	            
	            if(temp.equals(pos_start)){ // problema na compara��o de objetos
	            			repeat=true;
	            }
	           
	            if(!repeat) 
	            		return temp; 
	        }while(repeat);
			
	    	return null;	  
	}
   
	public static int obs(int tamanho) { // CRIA�AO DA % DE OBSTACULOS NO CUBO
		
		System.out.println("Porcentagem de obstaculos[%]:");
		scanner = new Scanner(System.in);
		int porcentagem = scanner.nextInt();
		porcentagem = (int) ((Math.pow(tamanho, 3)*porcentagem)/100); //27/2=13,5 ou 13 obstaculos
		if(porcentagem == Math.pow(tamanho,3) || porcentagem < 0) {
			System.out.print("Valor inv�lido!\tReduzido para 90%");
			return (int)((Math.pow(tamanho, 3)*90)/100);
		}
		
		return porcentagem;		
	}
}
	



