import java.util.PriorityQueue;
import java.util.Random;
import static java.lang.Math.pow;
import static java.lang.Math.sqrt;

public class buscaA {
	
	public static boolean fechados[][][];
	public static celula_bloco[][][] cubo;
	
	public static void ini(celula_bloco pos_start,celula_bloco pos_goal,int tamanho, int obstaculos){ 
		
		//INICIALIZA��O
		cubo = new celula_bloco[tamanho][tamanho][tamanho];
		fechados = new boolean[tamanho][tamanho][tamanho];
		
		PriorityQueue<celula_bloco> abertos = new PriorityQueue<>((celula_bloco o1, celula_bloco o2) ->{
				if(o1.finalCost > o2.finalCost) return 1;
				else if (o1.finalCost < o2.finalCost) return -1;
				else return 0; });	
         //POPULA��O DO CUBO (CUSTOS H E G DE CADA POSICAO 
         for(int i=0;i<cubo.length;i++)
             for(int j=0;j<cubo[i].length;j++)
            	 for(int k=0;k<cubo[i][j].length;k++){
	                 	cubo[i][j][k] = new celula_bloco(i, j, k);
	                 	//Distancia do ponto atual at� o ponto goal
	                 	cubo[i][j][k].heuristicCost = (int) sqrt(pow(pos_goal.geti()-i, 2) + pow(pos_goal.getj()-j, 2) + pow(pos_goal.getk()-k, 2));
	                 	//Custo de passo random
	                 	cubo[i][j][k].gCost = g();
	                 	//System.out.print(cubo[i][j][k].heuristicCost+" ");
          }      
              
        //para o primeiro n�, a distancia � totalmente heuristica, e o custo g � zero
        cubo[pos_start.geti()][pos_start.getj()][pos_start.getk()].finalCost = 0;
        cubo[pos_start.geti()][pos_start.getj()][pos_start.getk()].gCost = 0;
        //CALULO DO VALOR HEURISTICO [LINHA RETA] ENTRE POS GOAL-POS_START
        cubo[pos_start.geti()][pos_start.getj()][pos_start.getk()].heuristicCost = (int) sqrt(pow(pos_goal.geti()-pos_start.geti(), 2) + pow(pos_goal.getj()-pos_start.getj(), 2) + pow(pos_goal.getk()-pos_start.getk(), 2));
        //System.out.print(cubo[pos_start.getx()][pos_start.gety()][pos_start.getz()].heuristicCost);
        
        //Randomicamente adicionar obstaculos, com a % passada pelo user
        obstaculos_grid(pos_start,pos_goal,tamanho,obstaculos); 
       
        //Print do cubo com valores heuristicos
        printGrid_h(pos_start,pos_goal);
        
        //Inicio do processo de busca no cubo
        porcorrer_grid(pos_start,pos_goal,abertos,obstaculos); 
        
        //Print do cubo com valores finais
        printGrid_f(pos_goal, pos_goal);
        
        //PRINTAR O CAMINHO PERCORRIDO
         if(fechados[pos_goal.geti()][pos_goal.getj()][pos_goal.getk()]){
              System.out.println("Ordem de expans�o dos n�s: ");
              celula_bloco current = cubo[pos_goal.geti()][pos_goal.getj()][pos_goal.getk()];
              System.out.print(current); //printa o estado goal
              while(current.parent!=null){
                  System.out.print(" <- "+current.parent); //printa o pai do atual, at� o estado ini, q o ini sempre � null o pai
                  current = current.parent;
              } 
              System.out.println("\n");
              System.out.print("Custo total da rota: "+cubo[pos_goal.geti()][pos_goal.getj()][pos_goal.getk()].finalCost);
              
         }else 
        	 System.out.println("Imposs�vel expandir outros n�s!"); //caso sejam bloqueadas as rotas
	}
	
	private static void printGrid_h(celula_bloco pos_start, celula_bloco pos_goal) { //PRINT DO CUBO COM OS VALORES HEURISTICOS
		
		System.out.println("\nGrid:[custos heuristicos]");
		for(int i=0;i<cubo.length;i++){
            for(int j=0;j<cubo[i].length;j++){
           	 for(int k=0;k<cubo[i][j].length;k++){
	               if(i==pos_start.geti()&&j==pos_start.getj()&&k==pos_start.getk())System.out.print("INI "); //POSI��O INICIAL
	               else if(i==pos_goal.geti() && j==pos_goal.getj()&& k==pos_goal.getk())System.out.print("OBJ ");  //POSI��O FINAL
	               else if(cubo[i][j][k]!=null)System.out.printf("%-3d ", cubo[i][j][k].heuristicCost );
	               else System.out.print("BL  "); 
	            }
            	System.out.println();
            }
            System.out.println("------------------");
        }
		System.out.println();
	}

	private static void printGrid_f(celula_bloco pos_start, celula_bloco pos_goal) { //PRINT DO CUBO COM OS VALORES FINAIS
			
		System.out.println("\nGrid:[custos p/ c�lula]");
		for(int i=0;i<cubo.length;i++){
			for(int j=0;j<cubo[i].length;j++){
				for(int k=0;k<cubo[i][j].length;k++){
		           	 if(cubo[i][j][k]!=null)System.out.printf("%-3d ", cubo[i][j][k].finalCost); //Printa os custos calculados para cada n�
		           	 else System.out.print("BL  ");
		        }
		       System.out.println();
		        }
		       System.out.println("------------------");
		    }
		    System.out.println();
	}

	public static int g() { //ESCOLHA RANDOM DE UM VALOR DE PASSO P/ C�LULA
		Random custo = new Random();
  		int custop = custo.nextInt(10);	
		//System.out.print(custop+" ");
		return custop;
	}
	
	public static void obstaculos_grid(celula_bloco pos_start, celula_bloco pos_goal, int tamanho, int obstaculos){//ADICIONA OBSTACULOS A VARIADOS LOCAIS DA MATRIZ
		celula_bloco utilizados[] = new celula_bloco[obstaculos];
 		
	    java.util.Random x = new java.util.Random();
	    java.util.Random y = new java.util.Random();
	    java.util.Random z = new java.util.Random();
	    celula_bloco temp,temp2;
	    int i =0;
	   
	    while(i<obstaculos){
	    	
	        boolean repeat=false;
	        
	        do{
	            repeat=false;
	            int num1 = x.nextInt(tamanho);
	            int num2 = y.nextInt(tamanho);
	            int num3 = z.nextInt(tamanho);
	            temp = new celula_bloco(num1,num2,num3); //GER O celula_bloco RANDOM
	            
	            for(int j=0; j<utilizados.length; j++){
	            	temp2 = utilizados[j];
	            	if(temp.equals(temp2)) 
	            		repeat=true;
	            }
	            
	            if(!repeat)
	            	if(!temp.equals(pos_start) && !temp.equals(pos_goal) && !temp.equals(null)) {
			            		utilizados[i] = temp;
			            		//System.out.print(temp+" ");	
			            		cubo[num1][num2][num3] = null;
			            		i++;
	            	}	
	        	}while(repeat);	  
	    }	//System.out.print(i);
}
	
	public static void astar(celula_bloco current, celula_bloco temp, int custo,PriorityQueue<celula_bloco> abertos){ //ATUALIZAR O CUSTO, E N�		
								// A* //
		if(temp == null || fechados[temp.i][temp.j][temp.k]) return;//Verifica se j� n foi visitado
       
        int custo_final = temp.heuristicCost+custo; //valor da distancia heuristia nao conhecida + valor do passo
        boolean NosAbertos = abertos.contains(temp);
        
        if(!NosAbertos || custo_final<temp.finalCost){
            temp.finalCost = custo_final; //atualiza o custo
            temp.parent = current; //referencia do pai
            if(!NosAbertos) {
            	abertos.add(temp);
            	System.out.println("N� atual expandido: " +temp);
            } 
            				   // A* //
        }
    }
	
	public static void porcorrer_grid(celula_bloco pos_start, celula_bloco pos_goal,PriorityQueue<celula_bloco> abertos, int obstaculos){ //FUNCAO QUE FAZ COM QUE O ALG "ANDE" NO CUBO
		 
			celula_bloco pos = pos_start;
		 	abertos.add(pos);
		 	
		 //	int camblock=0;
		 //	boolean found = false;
	        
		 	while((!abertos.isEmpty())){
		 		
		 		celula_bloco current = abertos.poll();
		 		
		 		if(current==null) {
		 			break;
		 			/*
		 				camblock++;
		 				if(camblock == obstaculos)
		 					break; //CASO J� ANDOU E ESTAO BLOQUEADOS, VOLRA PRA INI
		 			 */
		 		}
		 		
		 		fechados[current.i][current.j][current.k] = true;		 				 	
		 	
		 		if(current.equals(pos_goal)) { //QUANDO ACHAR O CAMINHO, ALTERA Q ACHOU E J� RETORNA PRA INI
					System.out.println("N� atual expandido" +current);
					return;
		 		}
		 		
		 		celula_bloco temp;
		 		
		 		try {
		 			//AQUI � FEITO O PROCESSO DE "ANDAR PELO CUBO"
		 			if(current.i-1>=0){
		 				temp = cubo[current.i-1][current.j][current.k];
		 				temp.gCost = cubo[current.i-1][current.j][current.k].gCost;
		 				astar(current, temp, current.finalCost+temp.gCost, abertos);
		            } 
		 			
		 			if(current.j-1>=0){
		            	temp = cubo[current.i][current.j-1][current.k];
		            	temp.gCost = cubo[current.i][current.j-1][current.k].gCost;
		            	astar(current, temp, current.finalCost+temp.gCost, abertos);
		            }
		 			
		 			if(current.k-1>=0){
		 				temp = cubo[current.i][current.j][current.k-1];
		 				temp.gCost = cubo[current.i][current.j][current.k-1].gCost;
		 				astar(current, temp, current.finalCost+temp.gCost, abertos);
		 			}
		 			
		 			if(current.k+1<cubo[0][0].length){
		 				temp = cubo[current.i][current.j][current.k+1];
		            	temp.gCost = cubo[current.i][current.j][current.k+1].gCost;
		            	astar(current, temp, current.finalCost+temp.gCost, abertos);
		            }
		 			
		 			if(current.j+1<cubo[0].length){
		            	temp = cubo[current.i][current.j+1][current.k];
		            	temp.gCost = cubo[current.i][current.j+1][current.k].gCost;
		            	astar(current, temp, current.finalCost+temp.gCost, abertos);
		            }
		 					 			
		 			if(current.i+1<cubo.length){
		 				temp = cubo[current.i+1][current.j][current.k];
		 				temp.gCost = cubo[current.i+1][current.j][current.k].gCost;
		 				astar(current, temp, current.finalCost+temp.gCost, abertos);
		 			}

		 		}catch (NullPointerException e) {
		 			continue; 
		 			/* TIVE QUE TRATAR ESTA EXCEPTION, POIS ELE ESTAVA INDEXADO ERRADO QUANDO ALTERAVA 
		 			 					A LISTA DE ABERTOS EM ATUALIZAR CUSTO */
	            }
		 	}
	}

}