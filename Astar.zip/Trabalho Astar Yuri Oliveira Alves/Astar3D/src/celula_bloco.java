import java.util.Objects;

public class celula_bloco{  
	//CLASSE DE INICIALIZA��O DA GRID
	        int heuristicCost =  0; //Custo Heuristico
	        int gCost = 0; //Custo g
	        int finalCost = 0; //Custo total
	        
	        int i,j,k;
	        celula_bloco parent; 
	        
	        celula_bloco(int i, int j, int k){//GRID 3D
	            this.i = i;
	            this.j = j; 
	            this.k = k; 
	        }
	        
	        public int geti() {
	            return i;
	        }
	        
	        public int getj() {
	            return j;
	        }
	        
	        public int getk() {
	            return k;
	        }
	        
	        public int getheuristic() {
	        	return heuristicCost;
	        }
	        
	        public boolean equals(Object o) {
	            // self check 
	            if (this == o) 
	                return true;
	            // null check
	            if (o == null)
	                return false;
	            // type check and cast
	            if (getClass() != o.getClass())
	                return false;
	            celula_bloco pos = (celula_bloco) o;  
	            
	            if (Objects.equals(i,pos.geti())
	            		&& Objects.equals(j,pos.getj())
            			&& Objects.equals(k,pos.getk()))
	            	return true;
	           
	            // field comparison
	            return Objects.equals(i,pos.geti())
	            		&& Objects.equals(j,pos.getj())
            			&& Objects.equals(k,pos.getk());
	        }
	        
	        @Override
	        public String toString(){
	        	//return "["+this.i+", "+this.j+"]";
	            return "["+this.i+", "+this.j+", "+this.k+"]";
	        }
	    }